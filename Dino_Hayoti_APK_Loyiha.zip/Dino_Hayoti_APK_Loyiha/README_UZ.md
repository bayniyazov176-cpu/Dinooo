# Dino Hayoti 3D — APK tayyorlash loyihasi

Bu loyiha siz yuborgan `index-7.html` o‘yinini Android ilovasi ichida ochadi. Ilova landshaft (telefonni yonboshlab) rejimida ishlaydi.

## APK olish — Android telefon orqali

1. ZIP faylni oching.
2. GitHub’da yangi repository yarating (masalan, `Dino-Hayoti`).
3. ZIP ichidagi **fayllar va papkalarni** repository ildiziga yuklang. `README_UZ.md`, `app`, `.github`, `build.gradle`, `settings.gradle`, `gradle.properties` ko‘rinishi kerak.
4. GitHub repository ichida **Actions** bo‘limini oching.
5. `Build Dino Hayoti APK` workflow’ni tanlang va **Run workflow** tugmasini bosing. Agar avtomatik ishga tushmasa, repository fayllarini `main` branch’ga yuklanganini tekshiring.
6. Build tugagach, shu run sahifasining pastidagi **Artifacts** хэсэгidan `Dino-Hayoti-APK` ZIP’ni yuklab oling.
7. Yuklab olingan artifact ZIP’ni oching. Ichida `app-debug.apk` bo‘ladi. Uni telefonga o‘rnatish uchun Android ruxsat so‘rashi mumkin.

## Muhim eslatmalar

- Ushbu muhitda Android SDK/Gradle mavjud bo‘lmagani sababli APK’ni bu yerda kompilyatsiya qilib tekshirishning imkoni bo‘lmadi. GitHub Actions loyihani bulutda kompilyatsiya qiladi.
- O‘yin Three.js’ni CDN’dan yuklaydi; birinchi ishga tushishda internet kerak. Keyinchalik ham ushbu kutubxona CDN’da mavjud bo‘lishi kerak.
- 3D grafika ishlashi telefonning WebGL va WebView imkoniyatlariga bog‘liq.
- Bu debug APK; ommaviy tarqatish uchun imzolangan release APK alohida tayyorlanadi.
